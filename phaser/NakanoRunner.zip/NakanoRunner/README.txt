README 
Noriaki Nakano 
nnakano@ucsc.edu 
1418185
Endless Runner Progress

Files:
	html:
		index.html
	js:	
		init.js
		util.js
		menu_state.js
		play_state.js 
		main.js
		

CONTROLS:
Arrow Keys OR WASD: movement 
SPACEBAR: shoot (not fully implemented, recovery mechanic is implemented) 
SHIFT: boost speed (recovers while not using) 
Z or NUMPAD_1: barrier (will not recover after using)
x or NUMPAD_2: addtional feature(not implemented) 
c or NUMPAD_3: additional feature(not implemented)

game will be over when the score hits 3000

Asset Redfighter:
This work has been released under the Creative Commons BY License: https://creativecommons.org/licenses/by/4.0/
By MillionthVector (http://millionthvector.blogspot.de)